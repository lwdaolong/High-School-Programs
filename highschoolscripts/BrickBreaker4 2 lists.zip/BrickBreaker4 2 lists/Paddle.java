
/**
 * Write a description of class Paddle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Paddle
{
    private int x,y;
    
    private double vx;
    
    Paddle(int x, int y){
        this.x= x;
        this.y = y;
    }
    
    public void move(){
        x += vx;
        if(x <= 0) { //left side
           this.vx = - vx;
        }
        if(x >= 400) { //right side
            this.vx = - vx;
        }
    }
    
    public void setX(int x){
        this.x = x;
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
    
    public void setVX(double vx){
        this.vx = vx;
    }
}
