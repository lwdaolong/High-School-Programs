
import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.event.*;

public class m extends JApplet implements Runnable, KeyListener 
{
    Thread t;
    ArrayList <String> strings = new ArrayList<String>();
    char [][] maze;
    boolean [][] viz;
    Player player1;
    Player player2;

    int startx;
    int starty;

    int finishx;
    int finishy;
    
    boolean p1win = false;
    boolean p2win = false;

    public void init()
    {
        addKeyListener(this);
        setFocusable(true);

        t = new Thread(this);
        t.start();
        try {
            FileInputStream fs = new FileInputStream("maze.txt");
            DataInputStream in = new DataInputStream(fs);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            while ((strLine = br.readLine()) != null)   {
                strings.add(strLine);
            }
            in.close();
        }catch (Exception e){}

        maze = new char[strings.size()][strings.get(0).length()];

        for(int i=0; i < maze.length; i++){
            for(int t =0; t< maze[0].length; t++){
                maze[i][t] = strings.get(i).charAt(t);   
                if(strings.get(i).charAt(t) == 'z'){
                    startx = t;
                    starty =i;
                }
                else if(strings.get(i).charAt(t) == 'a'){
                    finishx = t;
                    finishy =i;
                }
            }
        }

        viz = new boolean [strings.size()][strings.get(0).length()];
        
        player1 = new Player(startx, starty, 1);
        player2 = new Player(finishx, finishy, 2);

        repaint();

    }

    public void run(){
        try{
            while (true){
                //repaint();

                
                //repaint();
                t.sleep(100);
            } 
        }
        catch (InterruptedException e) {}
    }

    public void paint(Graphics g) {
        if(!win()){for(int i =0; i < maze.length; i++){
            for(int t =0; t< maze[0].length; t++){
                if(maze[i][t] == '*'){
                    g.setColor(Color.black);
                }else if(maze[i][t] == '.'){
                    g.setColor(Color.white);
                }else if(maze[i][t] == 'a'){
                    g.setColor(Color.green);
                }else if(maze[i][t] == 'z'){
                    g.setColor(Color.red);
                }
                g.fillRect(t*20,i*20,20,20);
            }
        }

                for(int i =0;i< viz.length; i++){
            for(int t=0; t< viz[0].length; t++){
                if(viz[i][t] == false){
                     g.setColor(Color.green);
                     g.fillRect(t*20, i*20,20,20);
                    }
                
            }
        }
        
        if(player1.getColor() ==1){
            g.setColor(Color.blue);
            g.fillRect(player1.getX()*20, player1.getY()*20,20,20);
        }
        if(player1.getColor() ==1){
            g.setColor(Color.yellow);
            g.fillRect(player2.getX()*20, player2.getY()*20,20,20);
        }
        
        
    }
else{
    if(p1win){
        g.setColor(Color.blue);
        g.fillRect(0, 0,500,500);
    }
    if(p2win){
         g.setColor(Color.yellow);
          g.fillRect(0, 0,500,500);
    }
    
}
}

    public void keyPressed(KeyEvent e) {
        if(e.getKeyChar() == 'w') {
            move(player2, 0);
            repaint();
        }
        if(e.getKeyChar() == 'a') {
            repaint();
            move(player2, 1);
              
        }
        if(e.getKeyChar() == 's') {
            move(player2, 2);
              repaint();
        }
        if(e.getKeyChar() == 'd') {
            repaint();
            move(player2, 3);
              
        }
        if(e.getKeyChar() == 'i') {
            move(player1, 0);
              repaint();
        }
        if(e.getKeyChar() == 'j') {
           repaint();
            move(player1, 1);
              
        }
        if(e.getKeyChar() == 'k') {
            move(player1, 2);
              repaint();
        }        if(e.getKeyChar() == 'l') {
          repaint();
            move(player1, 3);
              
        }
    }

    public void keyTyped(KeyEvent e) {}

    public void keyReleased(KeyEvent e) {

    }

    public void move(Player p, int direction){
        int testx = p.getX();
        int testy = p.getY(); 
 
        if(direction == 0){
            if(maze[p.getY() -1][p.getX()] != '*')
                p.setY(testy -=1);
        }
        else  if(direction == 1){
            if(maze[p.getY()][p.getX()-1] != '*')
                p.setX(testx -=1);
        }
        else if(direction == 2){
            if(maze[p.getY() +1][p.getX()] != '*')
                p.setY(testy +=1);
        }
        else if(direction == 3){
            if(maze[p.getY() ][p.getX()+1] != '*')
                p.setX(testx +=1);
        }
        
                                               if(player1.getX() >-1 && player1.getX() < maze[0].length && player1.getY() >-1 && player1.getY() < maze.length){
                    viz[player1.getY()][player1.getX()] = true;
                    viz[player1.getY()][player1.getX()+1] = true;
                    viz[player1.getY()][player1.getX()-1] = true;
                    viz[player1.getY()+1][player1.getX()] = true;
                      viz[player1.getY()-1][player1.getX()] = true;
                      viz[player1.getY()-1][player1.getX()-1] = true;
                      viz[player1.getY()-1][player1.getX()+1] = true;
                      viz[player1.getY()+1][player1.getX()-1] = true;
                      viz[player1.getY()+1][player1.getX()+1] = true;

            }else{
            
            }
            
                                                           if(player2.getX() >-1 && player2.getX() < maze[0].length && player2.getY() >-1 && player2.getY() < maze.length){
                    viz[player2.getY()][player2.getX()] = true;
                    viz[player2.getY()][player2.getX()+1] = true;
                    viz[player2.getY()][player2.getX()-1] = true;
                    viz[player2.getY()+1][player2.getX()] = true;
                      viz[player2.getY()-1][player2.getX()] = true;
                      viz[player2.getY()-1][player2.getX()-1] = true;
                      viz[player2.getY()-1][player2.getX()+1] = true;
                      viz[player2.getY()+1][player2.getX()-1] = true;
                      viz[player2.getY()+1][player2.getX()+1] = true;

            }else{
            
            }
    }

     public boolean win(){
         if(player1.getX() == finishx && player1.getY() == finishy){
             p1win = true;
            return true;
            }
         else if(player2.getX() == startx && player2.getY() == starty){
             p2win = true;
            return true;
            }else{
                return false;
            }
        }
    
        
    
}