import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class Zombicide extends JApplet implements Runnable, KeyListener, MouseListener{
    Thread t;
    Hero h = new Hero();
    ArrayList<Bullet> bullets = new ArrayList();
    public void init() {
        addKeyListener(this);
        addMouseListener(this);
        setFocusable(true);
        t = new Thread (this);
        t.start();
    } 
    public void run(){
        try{
            while (true){
                t.sleep(50);
                repaint();
                h.move();
            }
        }
        catch (InterruptedException e) {}
    }
    public void paint(Graphics g) {
        g.fillRect(0,0,600,600);
        g.setColor(Color.white);
        g.fillOval(h.x,h.y,30,30);
        
    }

    public void keyTyped(KeyEvent e) { 
        if(e.getKeyChar()=='a'){
        h.vx=-3;
    }
        if(e.getKeyChar()=='d'){
        h.vx=3;
    }
        if(e.getKeyChar()=='w'){
        h.vy=-3; 
    }
        if(e.getKeyChar()=='s'){
        h.vy=3;
    }
}


    


   public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
    
  public void mousePressed(MouseEvent e) {
        double dx = e.getX() - h.x;
        double dy = e.getY() - h.y;
        bullets.add(new Bullet(h.x, h.y, Math.atan2(dy, dx)));
    }

    public void mouseReleased(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}
class Hero {
    int x,y,vx,vy;
    // variables
    Hero() {
        x=
        y=
        vx=0;
        vy=0;
        
    }
    void move() {
        x=x+vx;
        y=y+vy;
        
    }
}

class Bullet {
    double x, y, d;
    Bullet(double x, double y, double d) {
        this.x = x;
        this.y = y;
        this.d = d;
    }
    void move() {
        x = x + 4 * Math.cos(d);
        y = y + 4 * Math.sin(d);
    }
}

