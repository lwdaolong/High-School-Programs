import java.util.*;
public class deal
{
    // instance variables - replace the example below with your own
    public static void main(String[] args)
	{
		Deck test = new Deck();
		  
		test.Shuffle();  
		
		ArrayList <Card> hand = test.Deal(5);
			for(int i  =0;  i<4;i++){
	    System.out.print(hand.get(i).getName() + ", ");
		 }
		 for(int i  =4;  i<5 ;i++){
	    System.out.print(hand.get(i).getName() +  ".");
		 }
	}
}
