import java.util.*;
public class Deck
{
  private ArrayList <Card> arr = new ArrayList();
 // private Card[] arr = new Card[52];
  int index = 0;
  Deck(){
      
      for(int suit =1; suit<=4;suit++){
          for(int rank =2; rank<=14; rank++){
              arr.add( new Card(suit, rank));
  //           index ++;
            }
        }
    
    }
    
    void Shuffle(){
        for(int z =0; z<1000;z++){
            int a = (int)(Math.random()*52);
            //int b = (int)(Math.random()*52);
            
            Card temp = arr.get(a);
            arr.remove(a);
            arr.add(temp);
            
        }
    }
    
    ArrayList <Card> Deal(int a){
        ArrayList <Card> hand = new ArrayList() ;
        if(arr.size() >=a){
            for( int i =0; i <a ;i++){
                hand.add(arr.get(0));
                arr.remove(0);
            }
            return hand;
        }else{
            hand = arr;
            arr.clear();
            return hand;
        }
       
    }
}
