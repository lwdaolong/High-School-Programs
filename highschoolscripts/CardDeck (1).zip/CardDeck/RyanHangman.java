import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class RyanHangman extends Applet implements KeyListener{
    String[] words={"mitty","science","basketball","football","monarch"};
    String theWord;
    char[] word;
    char [] guess;
    int wrongguess = 0;
 
    public void init() {
        int rand=(int)(Math.random()*5);
        theWord=words[rand];
        word= new char [theWord.length()];
        guess = new char [theWord.length()];
    
    
       for(int i=0; i<theWord.length(); i++){
           word[i] = theWord.charAt(i);
           guess[i]='_';
        }
        addKeyListener(this);
        setFocusable(true);
              
    }

    public void paint(Graphics g){
        g.setColor(Color.white);       
        g.fillRect(0,0,500,500);
        g.setColor(Color.black);
        for(int i=0; i<word.length; i++){        
            g.drawString(""+guess[i], 40*i,100);
            
        }
       
        if(wrongguess >=1){
            g.drawOval(350,200,30,30); 
        }
        if(wrongguess >=2){
           g.drawLine(365,230,365,300);
        }
        if(wrongguess >=3){
            g.drawLine(365,300,320,340);
        }
        if(wrongguess >=4){
            g.drawLine(365,300,410,340);
        }
        if(wrongguess >=5){
            g.drawLine(365,250,320,205);
        }
        if(wrongguess >=6){
            g.drawLine(365,250,410,205);
            g.drawString("You lose...",250,50);
        }
        
        boolean a=false;
        for(int i=0;i<theWord.length(); i++){
        }
    }   
    public void keyPressed(KeyEvent e) {
        char guess=e.getKeyChar();
        if(!isinword(guess)){
            wrongguess++;
        }
        repaint();
        
    }
    public boolean isinword (char c)
    {
        int ret=0;
        for(int i=0; i<word.length; i++){
            if(c==word[i]){
                guess[i]=c;
                ret++;
            }
        }
        if(ret>0)return true;
        return false;
    }
    
    public void keyTyped(KeyEvent e){}
    public void keyReleased(KeyEvent e){}

}
