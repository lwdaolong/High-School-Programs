
/**
 * Write a description of class Deck here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Deck
{
  private Card[] arr = new Card[52];
  int index = 0;
  Deck(){
      
      for(int suit =1; suit<=4;suit++){
          for(int rank =2; rank<=14; rank++){
              arr[index] = new Card(suit, rank);
             index ++;
            }
        }
    
    }
    
    void Shuffle(){
        for(int z =0; z<1000;z++){
            int a = (int)(Math.random()*52);
            int b = (int)(Math.random()*52);
            
            Card temp = arr[a];
            arr[a] = arr[b];
            arr[b] = temp;
            
        }
    }
    
    Card[] Deal(int a){
        Card[] hand = new Card[a];
        for(int i =0; i<hand.length;i++){
            hand[i] = arr[i];
        }
        return hand;
    }
}
