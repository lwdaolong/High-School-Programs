
/**
 * Write a description of class main1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class main1
{
    // instance variables - replace the example below with your own
    public static void main(String[] args)
	{
		Deck test = new Deck();
		  
		test.Shuffle();  
		
		Card[] hand = test.Deal(5);
			for(int i  =0;  i<hand.length;i++){
	    System.out.print(hand[i].getName());
		 }
	}
}
