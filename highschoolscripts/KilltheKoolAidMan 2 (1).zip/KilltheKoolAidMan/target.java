
/**
 * Write a description of class target here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class target
{
     int x;
     int y;
     int r;
    
    // speed, hp, maybe?
    // instance variables - replace the example below with your own
    public target(int x, int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
        
    }
    
    public int getX(){
        return (int)x;
    }
    
      public int getY(){
        return (int)y;
    }
    
      public int getR(){
        return (int)r;
    }
    
    public void move(){
     
            this.x +=10;
            if(this.x>1000){
                x=0;
            }
            
 
    }
    
    
    
    
    
    
}
