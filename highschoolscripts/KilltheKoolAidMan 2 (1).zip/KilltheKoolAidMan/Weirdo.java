
/**
 * Write a description of class Weirdo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Weirdo extends target
{
    private int vy;
    private int vx;
    
    Weirdo(int x,int y,int r){
        super(x,y,r);

        vx = 5;
        vy= 10;
    }

    public void move(){
        this.x += vx;
        this.y +=vy;
        
        if(this.x > 80){
            vx = -5;
        }
        if(this.x< 0){
            vx =5;
        }
        if(this.y>700){
           y=20;
        }

    }
}
