import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.util.*;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.event.*;

public class demo extends JApplet implements Runnable, MouseListener
{
    Thread t;
    
    Image zombie;
    
    int mx =0;
    int my =0;
    
    ArrayList <target> targets = new ArrayList();
    
    public void init(){
        zombie = getImage(getDocumentBase(), "zombie.gif");
        addMouseListener(this);
        resize(1000, 1000);
        setFocusable(true);
        t = new Thread(this);
        t.start();
        
        for(int i = 0; i< 10; i++){
            targets.add(new Slider(i*80, 20, 40));
            targets.add(new Popper(i*40+500, 500, 20));
            targets.add(new Weirdo(0, i*80, 40));
        }
    }

    public void run(){
        try{
            while(true){
                
                //for(target l: targets){
                  //  l.move(1);     
                //}
                for(int i = 0; i < targets.size();i++){
                    targets.get(i).move();
                }
                
                t.sleep(100);
                repaint();
            }
        }
        catch (InterruptedException e){}
    }
    public void paint(Graphics g){
        g.clearRect(0, 0, 1000, 1000);
        if(targets.size()>0){
        for(target t: targets){
            g.drawString("KILL THE KOOL AID MEN",500,500);
             if(t instanceof Slider){
                                g.setColor(Color.red);
                            }else if(t instanceof Popper){
                                g.setColor(Color.blue);
                                
                                
                            }
                             else if(t instanceof Weirdo){
                                g.setColor(Color.green);
                                
                                
                            }else{
                                g.setColor(Color.yellow);
                            }
            // g.fillOval(t.getX(), t.getY(), t.getR(),t.getR());
             g.drawImage(zombie,  t.getX(), t.getY(), t.getR(), t.getR(), this);
        }}else{
        g.setColor(Color.green);
        g.fillRect(0,0,1000,1000);}
    } 
    public void mousePressed(MouseEvent e) {
        
    for(int i =0; i< targets.size(); i++){
        if(e.getX()> targets.get(i).getX() && e.getX()< targets.get(i).getX() +  targets.get(i).getR() && e.getY()> targets.get(i).getY()&& e.getY()< targets.get(i).getY() +  targets.get(i).getR()){
            targets.remove(i);
            repaint();
        }
    }
    }
    public void mouseClicked(MouseEvent e) {

    }
    
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}
