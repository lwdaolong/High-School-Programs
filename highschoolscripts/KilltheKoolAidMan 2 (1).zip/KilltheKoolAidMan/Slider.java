
/**
 * Write a description of class Slider here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Slider extends target
{
    // instance variables - replace the example below with your ownvx;
    private int vx;
    Slider(int x,int y,int r){
        super(x,y,r);

        vx= 10;
    }

    public void move(){

        this.x +=vx;
        if(this.x>1000){
            x=0;
        }

    }
}
