
/**
 * Write a description of class Popper here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Popper extends target
{
    // instance variables - replace the example below with your ownvx;
    private int vy;
    Popper(int x,int y,int r){
        super(x,y,r);

        vy= -10;
    }

    public void move(){

        this.y +=vy;
        vy +=1;
        if(this.y>700){
            vy=-20;
        }

    }
}
