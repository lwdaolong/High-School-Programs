
/**
 * Write a description of class Dive here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dive
{
    private String name;
    private double dd;
    private double[] scores;
    
    Dive(String name, double dd){
        this.name =name;
        this.dd =dd;
        this.scores = new double[5];
    }
    Dive(String name, double dd, double[] scores){
        this.name =name;
        this.dd =dd;
        this.scores = scores;
    }
    public void results (double [] scores){
        this.scores =scores;
    }
    
    
    
    public double getScore(){
        double sumscore =0;
        double a = scores[0];
        double b = scores[0];
        for(int i = 0; i< scores.length; i++){
           sumscore += scores[i];
            if(scores[i] >a)
                a = scores[i];
            if(scores[i] < b)
                b = scores[i];
        }
    return dd*(sumscore - a - b);
}
}
