
/**
 * Write a description of class a here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class a
{
    public static void main(String [] args) {
        Dive[] list = new Dive[11];
        list[0] = new Dive("Forward 1 1/2 Pike", 1.7, new double[]{5.5, 6.0, 5.0, 5.5, 6.0});
        list[1] = new Dive("Back 1 1/2 Tuck", 2.0, new double[]{7.5, 6.5, 7.0, 7.5, 6.5});
        list[2] = new Dive("Reverse 1 1/2 Pike", 2.4, new double[]{4.5, 4.0, 4.0, 5.5, 4.0});
        list[3] = new Dive("Inward 1 Tuck", 1.6, new double[]{7.5, 7.0, 8.0, 6.5, 7.0});
        list[4] = new Dive("Forward 1 1/2 Twist 1/2", 2.0, new double[]{7.5, 8.0, 7.0, 7.5, 7.0});
        list[5] = new Dive("Back 1 Twist 1/2", 1.9, new double[]{3.5, 4.0, 4.0, 4.5, 4.0});
        list[6] = new Dive("Reverse 1 Twist 1/2", 1.8, new double[]{7.5, 7.0, 7.0, 6.5, 7.0});
        list[7] = new Dive("Inward Dive Pike Twist 1/2", 1.9, new double[]{7.5, 7.0, 8.0, 8.5, 7.0});
        list[8] = new Dive("Forward 2 1/2 Tuck", 2.4, new double[]{4.5, 3.0, 4.0, 3.5, 4.0});
        list[9] = new Dive("Back 2 Pike", 2.5, new double[]{5.5, 6.5, 6.5, 6.5, 6.5});
        list[10] = new Dive("Inward 2 1/2 Pike", 3.4, new double[]{0, 0, 0, 0, 0});
        
        Diver d = new Diver("abc", list);
        
        System.out.println(d.meetScore());
    }
}
