
/**
 * Write a description of class Diver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Diver
{
   private String name;
   private Dive[] divescores;
   
   Diver(String name, Dive[] divescores){
       this.name = name;
       this.divescores = divescores;
    }
    
   public double meetScore(){
       double fscore =0;
       for(int i =0; i <divescores.length; i++){
           fscore+= divescores[i].getScore();
        }
       return fscore;
    }
}
