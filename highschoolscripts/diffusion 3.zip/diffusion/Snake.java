import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Snake extends JFrame {
    int width = 30;
    int height = 30;
    int size = 20;
    int delay = 500;

    ArrayList <Coord> parts1 = new ArrayList();
    ArrayList <Coord> parts2 = new ArrayList();
    int dir1 = 2, dir2 = 2;
    int apple_x, apple_y;

    int initSize = 1;
    boolean inGame = false;

    int PORT = 8901;
    Socket socket;
    BufferedReader in;
    PrintWriter out;

    Board board;

    public Snake (String serverAddress) throws Exception {
        try {
            socket = new Socket(serverAddress, PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        } catch (Exception e){}
        board = new Board();
        board.setBackground(Color.black);

        board.addKeyListener(new KeyAdapter() {
                public void keyPressed(KeyEvent e) {
                    int send = 0;
                    if(e.getKeyCode() == KeyEvent.VK_UP) send = 0;
                    if(e.getKeyCode() == KeyEvent.VK_LEFT) send = 1;
                    if(e.getKeyCode() == KeyEvent.VK_DOWN) send = 2;
                    if(e.getKeyCode() == KeyEvent.VK_RIGHT) send = 3;
                    out.println("MOVE " + send);
                }
            }
        );
        this.add(board);
        this.getContentPane().add(board, "Center");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(width * size, height * size);
        setResizable(false);
        setLocation(100, 100);

        Board b = new Board();
        addKeyListener(b);
        add(b);
        setVisible(true);

        Timer t = new Timer(delay, b);
        t.start();
    }

    public void play() throws Exception {
        String response;
        try {
            response = in.readLine();
            if (response.startsWith("WELCOME")) {
                char mark = response.charAt(8);
                this.setTitle("Snake - Player " + mark);
            }
            if(response.contains("All players connected"))
                inGame = true;
            while (true) {
                response = in.readLine();
                if(response.contains("All players connected"))
                    inGame = true;
                if(response.contains("Valid_Move")) {
                    int dir1 = Integer.parseInt(response.substring(11));        }
                if(response.contains("change")) {
                    int opp_dir = Integer.parseInt(response.substring(7));
                }
            }
        }
        finally {
            try {
                socket.close();
            }catch (Exception e) {}
        }
    }

    //  THIS IS WHERE YOU MUST DEAL WITH THE OPPONENT CHANGING DIRECTION                    

    //                 if (response.contains("MOVE")) {
    //                     int dir = Integer.parseInt(response.substring(5));
    //                 }
    //                 if (response.contains("OPPONENT")) {
    //                     int opp_dir = Integer.parseInt(response.substring(9));
    //                 }


    public static void main(String[] args) throws Exception {
        while (true) {
            String serverAddress;
            if(args.length == 0)
                serverAddress = "localhost";
            else
                serverAddress = args[0];
            Snake client = new Snake(serverAddress);
            client.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            client.setSize(800, 800);
            client.setVisible(true);
            client.setResizable(false);
            client.play();
        }
    }
    public class Board extends JPanel implements KeyListener, ActionListener {
        Board(){
            setFocusable(true);
            setBackground(Color.black);
            addKeyListener(this);
            for(int i = 0; i < initSize; i++){
                parts1.add(new Coord(3, 4 - i));
                parts2.add(new Coord(width - 3, 4 - i));
            }
            spawnApple();
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (inGame) {
                g.setColor(Color.red);
                g.fillRect(apple_x * size, apple_y * size, size, size);

                g.setColor(Color.green);
                for (int i = 0; i < parts1.size(); i++) {
                    g.fillRect(parts1.get(i).x * size, parts1.get(i).y * size, size, size);
                }
                g.setColor(Color.red);
                for (int i = 0; i < parts2.size(); i++) {
                    g.fillRect(parts2.get(i).x * size, parts2.get(i).y * size, size, size);
                }
                g.setFont(new Font("Arial", Font.BOLD, 24));
            } else {
                gameOver(g);
            }
        }

        public void actionPerformed(ActionEvent e) {
            System.out.println(parts1.get(0).y + " " + parts1.get(0).x + " " + dir1);
            tester();
            moveSnakes();
            repaint();
        }

        public void keyPressed(KeyEvent e) {
            System.out.println("PRESS");
            if(e.getKeyChar() == 'w') dir1 = 0;
            if(e.getKeyChar() == 'a') dir1 = 1;
            if(e.getKeyChar() == 's') dir1 = 2;
            if(e.getKeyChar() == 'd') dir1 = 3;
            //if(e.getKeyChar() == ' ') inGame = true;
        }

        public void keyReleased(KeyEvent e){}

        public void keyTyped(KeyEvent e){}

        private void tester(){
            if ( parts1.get(0).x >= width || parts1.get(0).x < 0 || parts1.get(0).y >= height || parts1.get(0).y < 0 ) {
                //inGame = false;
            }
            if ( parts2.get(0).x >= width || parts2.get(0).x < 0 || parts2.get(0).y >= height || parts2.get(0).y < 0 ) {
                //inGame = false;
            }
            for(int i = 1; i < parts1.size(); i++){
                if (parts1.get(i).x == parts2.get(0).x && parts1.get(i).y == parts2.get(0).y){
                    //inGame = false;
                }
            }
            for(int i = 1; i < parts2.size(); i++){
                if (parts2.get(i).x == parts1.get(0).x && parts2.get(i).y == parts1.get(0).y){
                    //inGame = false;
                }
            }
            if ((parts1.get(0).x == apple_x) && (parts1.get(0).y == apple_y)) {
                parts1.add(new Coord(parts1.get(parts1.size() - 1).x, parts1.get(parts1.size() - 1).y));
                spawnApple();
            }
            if ((parts2.get(0).x == apple_x) && (parts2.get(0).y == apple_y)) {
                parts2.add(new Coord(parts2.get(parts2.size() - 1).x, parts2.get(parts2.size() - 1).y));
                spawnApple();
            }
        }

        private void spawnApple() {
            apple_x = (int)(Math.random() * width);
            apple_y = (int)(Math.random() * height);
        }

        private void gameOver(Graphics g) {
            g.setColor(Color.white);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Game Over!", 20, 100);
            g.drawString("Press space to restart", 20, 150);
        }

        private void moveSnakes(){

            for (int i = parts1.size() - 1; i > 0; i--) {
                parts1.get(i).x = parts1.get(i-1).x;
                parts1.get(i).y = parts1.get(i-1).y;
            }
            for (int i = parts2.size() - 1; i > 0; i--) {
                parts2.get(i).x = parts2.get(i-1).x;
                parts2.get(i).y = parts2.get(i-1).y;
            }

            if(dir1 == 0) parts1.get(0).y--;
            if(dir1 == 3) parts1.get(0).x++;
            if(dir1 == 2) parts1.get(0).y++;
            if(dir1 == 1) parts1.get(0).x--;

            if(dir2 == 0) parts2.get(0).y--;
            if(dir2 == 3) parts2.get(0).x++;
            if(dir2 == 2) parts2.get(0).y++;
            if(dir2 == 1) parts2.get(0).x--;
        }
    }
}
class Coord {
    int x, y;
    Coord(int x, int y) {
        this.x = x;
        this.y = y;
    }
}