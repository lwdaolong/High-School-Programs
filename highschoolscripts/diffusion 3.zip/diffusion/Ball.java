public class Ball {
    double x;
    double y;
    double v; //velocity
    double a; //angle
    public Ball ( double x, double y, double v, double a) {
        this.x = x;
        this.y =  y;
        this.v = v;
        this.a = a;
    }

    void move() {
        x = x + v*Math.cos(a);
        y = y + v*Math.sin(a);
        if(y <= 0) { //top
            a = a*(-1);
        }
        if(y >= 200) { //bottom
            a = a*(-1);
        }
        if(x <= 0) { //left side
            a = Math.PI - a;
        }
        if(x >= 400) { //right side
            a = Math.PI - a;
        }

    }
    
    public void setA(double a){
        this.a = a;
    }
public void setX(int x){
    this.x = x;
}
    
    
    public int getX() {
        return (int) x;
    }
    public int getY() {
        return (int) y;
    }
    public double getA(){
        return a;
    }
    public double getV(){
        return v;
    }
}