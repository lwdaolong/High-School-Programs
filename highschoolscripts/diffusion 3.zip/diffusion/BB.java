import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class BB extends JApplet implements Runnable
{
    Thread t;
    Ball b = new Ball(20,45, 10, 1.3);
    int m = 100;
    int n = 100;

    public void init() {
       
        setFocusable(true);
        t = new Thread(this);
        t.start();


        
    }

    public void run(){
        try{
            while (true){
                
                
                   b.move();    
                if(b.getX() > p.getX() && b.getX() < p.getX() + 40 && b.getY() > p.getY() && b.getY() < p.getY() + 20){
                    b.setA(-1 * b.getA() ); //+ (b.getX()-p.getX())*.1)
                    //b.setA((((Math.PI)/2)*((b.getX()-p.getX())/40))-((3/4)*Math.PI));
                }
                for(int i = 0; i < bricks.length; i++){
                    if(bricks[i] != null){
                        if(b.getX() > bricks[i].getX() && b.getX() < bricks[i].getX() + bricks[i].getWidth() && b.getY() > bricks[i].getY() && b.getY() < bricks[i].getY() + bricks[i].getHeight()){
                            bricks[i] = null;
                            b.setA(-b.getA());
                        }
                        
                    }
                }
                
                repaint();
                t.sleep(100);
                }

             
        }
        catch (InterruptedException e) {}
   }
    public void paint(Graphics g) {
        if(running(bricks)){
        g.setColor(Color.white);
        g.fillRect(0,0,1000,1000);
               g.setColor(Color.black);
               g.drawRect(0,0,415,215);
        g.fillRect(p.getX(), p.getY(), 40, 20);
        g.fillOval(b.getX()-5, b.getY()-5, 10, 10);
        
        int z =0;
        

}
}

}
