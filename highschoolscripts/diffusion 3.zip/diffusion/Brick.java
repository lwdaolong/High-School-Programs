
/**
 * Write a description of class Brick here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Brick
{
  private int h,w, hp, x, y;
  
  Brick(int h, int w, int hp, int x, int y){
      this.h =h;
      this.w =w;
      this.hp =hp;
      this.x =x;
      this.y =y;
      
    }
    
    public int getHeight(){
        return h;
    }
    public int getWidth(){
        return w;
    }
    public int getHP(){
        return hp;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
}
