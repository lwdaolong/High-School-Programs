import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class SnakeServer {
    public static void main(String[] args) throws Exception {
        try (ServerSocket listener = new ServerSocket(8901)) {
            System.out.println("Snake Server is Running");
            while (true) {
                Game game = new Game();
                Game.Player X = game.new Player(listener.accept(), 'X');
                Game.Player O = game.new Player(listener.accept(), 'O');
                X.setOpponent(O);
                O.setOpponent(X);
                game.currentPlayer = X;
                X.start();
                O.start();
                
            }
        }
    }
}

class Game {

    private Player[][] board =new Player[10][10];
    Player currentPlayer;

    public boolean hasWinner() {
        
        return false;
    }

    public boolean tie() {
        for (int i = 0; i < board[0].length; i++) {
            for(int j = 0; j < board.length; j++) {
                if (board[j][i] == null) {
                    return false;
                }
            }
        }
        return true;
    }

    public synchronized boolean legalMove(int x, int y, Player pl) {

        return true;
    }

    class Player extends Thread {
        char mark;
        Player opponent;
        Socket socket;
        BufferedReader input;
        PrintWriter output;

        public Player(Socket socket, char mark) {
            this.socket = socket;
            this.mark = mark;
            try {
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                output = new PrintWriter(socket.getOutputStream(), true);
                output.println("WELCOME " + mark);
                output.println("TEXT Waiting for opponent to connect");
            } catch (IOException e) {
                System.out.println("" + e);
            }
        }

        public void setOpponent(Player opponent) {
            this.opponent = opponent;
        }

        public void myTurn(int x, int y) {
            output.println("OPPONENT_MOVED " + x +","+ y);
            if(hasWinner() == true)
                output.println("DEFEAT");
            else if(tie() == true)
                output.println("TIE");
            else
                output.println("");
        }
       

        public void run() {
            try {
                output.println("TEXT All players connected");
                if (mark == 'X') {
                    output.println("TEXT Your move");
                }

                while (true) {
                    String command = input.readLine();
                    if (command.startsWith("MOVE")) {
                        int x = Integer.parseInt(command.substring(5));
                        int y = 0;
                        if (legalMove(x, y, this)) {
                            output.println("VALID_MOVE");
                            if(hasWinner() == true)
                                output.println("VICTORY");
                            else if(tie() == true)
                                output.println("TIE");
                            else
                                output.println("");
                        } else {
                            output.println("TEXT ?");
                        }
                    } else if (command.startsWith("QUIT")) {
                        return;
                    }
                    if (command.startsWith("BLOCKS")) {                 // modified
                                output.println(command);
                                opponent.output.println(command);
                        }
                }
            } catch (IOException e) {
                System.out.println("" + e);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {}
            }
        }
    }
}
