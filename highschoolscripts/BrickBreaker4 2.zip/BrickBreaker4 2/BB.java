import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class BB extends JApplet implements Runnable, KeyListener, MouseListener, MouseMotionListener
{
    Thread t;
    Ball b = new Ball(20,45, 10, 1.3);
    Paddle p = new Paddle(200,180);
    int m = 100;
    int n = 100;
    int lives = 3;
    int score = 0;

    Brick[] bricks = new Brick[24];
    public void init() {
        addKeyListener(this);
        setFocusable(true);
        addMouseListener(this);
        addMouseMotionListener(this);
        t = new Thread(this);
        t.start();
        int xx= 0;
        int yy = 0;
        int i =0;

        for(int p =0; p< 3;p++){
            for(int l = 0; l<8; l++){
            bricks[i] = new Brick(10,40,(int)(Math.random() * 3) + 1,40+xx,10+yy);
            xx+= 40;
        i++;
        }
        xx = 0;
            yy += 10;
        }

    }

    public void run(){
        try{
            while (true){

                if( running(bricks)){ 
                    b.move();
                    p.move();
                    if(b.getY() >= 200){
                        lives --;
                        b = new Ball(200,100, 10, 1.3);
                    }
                    if(b.getX() > p.getX() && b.getX() < p.getX() + 40 && b.getY() > p.getY() && b.getY() < p.getY() + 20){
                        //b.setA(-1 * b.getA()); //+ (((b.getX()-p.getX())/40)*1));
                        //b.setA((((Math.PI)/2)*((b.getX()-p.getX())/40))-((3/4)*Math.PI));
                        b.setA((-0.5 * Math.PI) + (Math.PI *(b.getX() - p.getX() -20)/80));
                    }
                    for(int i = 0; i < bricks.length; i++){
                        if(bricks[i] != null){
                            if(b.getX() > bricks[i].getX() && b.getX() < bricks[i].getX() + bricks[i].getWidth() && b.getY() > bricks[i].getY() && b.getY() < bricks[i].getY() + bricks[i].getHeight()){
                                bricks[i].subtractHP();
                                b.setA(-b.getA());
                                score ++;
                                if(bricks[i].getHP() <=0)
                                {
                                bricks[i] = null;
                            }
                                
                            }

                        }
                    }

                    repaint();
                    t.sleep(100);
                }
                else{
                    repaint();
                    t.sleep(100);
                }
            } 
        }
        catch (InterruptedException e) {}
    }

    public void paint(Graphics g) {
        if(running(bricks)){
            g.setColor(Color.white);
            g.fillRect(0,0,1000,1000);
            g.setColor(Color.black);
            g.drawRect(0,0,415,215);
            g.fillRect(p.getX(), p.getY(), 40, 20);
            g.fillOval(b.getX()-5, b.getY()-5, 10, 10);
            g.drawString("Lives: " + lives, 50,270);
            g.drawString("Score: " + score, 50,250);
         //   g.drawString("Angle: " + b.getA(), 50,290);
            int z =0;

            for(int i =0; i< bricks.length;i++){
                if(bricks[i] != null){
                    if(bricks[i].getHP() ==1){
                         g.setColor(Color.green);
                    }
                    if(bricks[i].getHP() ==2){
                         g.setColor(Color.blue);
                    }
                    if(bricks[i].getHP() ==3){
                         g.setColor(Color.red);
                    }
                    
                    g.drawRect(bricks[i].getX(), bricks[i].getY(), bricks[i].getWidth(), bricks[i].getHeight());
                }}

        }
        else{
            if( lives > 0){
                g.setColor(Color.green);

            }
            else{
                g.setColor(Color.red);

            }
            g.fillRect(0,0,1000,1000);
            g.setColor(Color.white);
            g.drawString("Score: " + score, 200,200);
        }
    }

    public void keyPressed(KeyEvent e) {
        if(e.getKeyChar() == 'a') {
            p.setVX(-10);
        }
        if(e.getKeyChar() == 'd') {
            p.setVX(10);
        }                if(e.getKeyChar() == ' ') {
            p.setVX(0);
        }
    }

    public void keyTyped(KeyEvent e) {}

    public void keyReleased(KeyEvent e) {
        if(e.getKeyChar() == 'a') {
            p.setVX(0);
        }
        if(e.getKeyChar() == 'd') {
            p.setVX(0);
        }  
    }

    public void mouseDragged(MouseEvent e) {
        p.setX(e.getX());
        n = e.getY();
        repaint();
    }

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mousePressed(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mouseMoved(MouseEvent e) {}

    public boolean running(Brick [] arr){
        if(lives > 0){
            for(int i = 0; i < arr.length; i++){
                if(arr[i] != null){
                    return true;
                }
            }return false;
        }
        else{
            return false;
        }}

}
