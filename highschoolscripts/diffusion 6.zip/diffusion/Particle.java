
/**
 * Write a description of class Particle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Particle
{
 double x;
 double y;
 double vx;
 double vy;
 int radius;
 
 public Particle (double x, double y, double vx, double vy, int radius){
     this.x = x;
     this. y=y;
     this. vx = vx;
     this.vy = vy;
     this. radius = radius;
    }
    
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }
    public double getVX(){
        return vx;
    }
    public double getVY(){
        return vy;
    }
    public int getR(){
     return radius;
    }
    
    public void setVX(double vx){
        this.vx = vx;
    }
       public void setVY(double vy){
        this.vy = vy;
    }
    
    public void move(){
    x += vx;
    y += vy;
    
            if(y <= 0) { //top
            vy = - vy;
        }
        if(y >= 400) { //bottom
            vy = - vy;
        }
        if(x <= 0) { //left side
            vx = - vx;
        }
        if(x >= 400) { //right side
           vx = - vx;
        }
    
    
    }
    
    
    
    
}
