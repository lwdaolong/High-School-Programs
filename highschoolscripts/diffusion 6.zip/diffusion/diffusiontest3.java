
/**
 * Write a description of class diffusiontest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.util.concurrent.TimeUnit;

public class diffusiontest3 extends JApplet implements Runnable
{
    // size of board is 400 y direction, 400 x direction 
    //4 quadrants
    // spawn particles in one quadrant and see how lon git takes to
    Thread t;
    Particle[] arr = new Particle[50];
    boolean iscentered;
    int time;
    long startTime;
    long endTime;
    int sx;
    int sy;

    public void init(){

        setFocusable(true);
        t = new Thread(this);
        t.start();
        for(int i =0; i < arr.length; i++){
            if(i <25){
            arr[i] = new Particle(1 + Math.random()*200, 1+ Math.random()*200, 3, 3, 10);
        }else{
            
            arr[i] = new Particle(1 + Math.random()*200, 1+ Math.random()*200, 6, 6, 10);
        }
    
    }
        iscentered = centered(arr);
        startTime = System.nanoTime();
        sx=0;
        sy=0;
    }

    // instance variables - replace the example below with your own
    public void run(){
        try{
            while(!iscentered){
                t.sleep(20);
                for( Particle b : arr){
                    b.move();
                    repaint();
                }

                for(int i=0; i< arr.length; i++){
                    for(int j =0; j < arr.length; j++){
                        if(i!=j){
                            if(((Math.abs(arr[i].getX() - arr[j].getX()) < (double)arr[i].getR()) || (Math.abs(arr[i].getX() - arr[j].getX()) < (double)arr[j].getR()) ) && ((Math.abs(arr[i].getY() - arr[j].getY()) < (double)arr[i].getR()) || (Math.abs(arr[i].getY() - arr[j].getY()) < (double)arr[i].getR()))){
                                double vxtot = arr[i].getVX() + arr[j].getVX();
                                double vytot = arr[i].getVY() + arr[j].getVY();

                                double tmpx = Math.random() *vxtot +1;
                                double tmpy= Math.random() *vytot +1;

                                arr[i].setVX(tmpx);
                                arr[i].setVY(tmpy);
                                arr[j].setVX(vxtot - tmpx);
                                arr[j].setVY(vytot - tmpy);
                            }
                        }

                    }

                }
                iscentered = centered(arr);
                endTime = System.nanoTime();
                sx =0;
                sy=0;
                for(Particle b: arr){
                    sx += (b.getX());
                    sy+= (b.getY());
                }

            }
            for( Particle b : arr){
                b.setVX(0);
                b.setVY(0);
                repaint();
            } 

        }       
        catch (InterruptedException e) {}
    }

    public void paint(Graphics g) {

        g.setColor(Color.white);
        g.fillRect(0,0,1000,1000);
        g.setColor(Color.black);
        g.drawRect(0,0,400,400);
        for( int i =0; i< arr.length;i++){
            if( i< 25){
                g.setColor(Color.blue);
            }else{
                g.setColor(Color.yellow);
            }
           
            
            g.fillOval((int)arr[i].getX()-(arr[i].getR()/2), (int)arr[i].getY()-(arr[i].getR()/2), arr[i].getR(), arr[i].getR());
        }
        g.setColor(Color.black);
        g.drawString((endTime - startTime)/ 1000000000 + " seconds", 200,390);
        g.setColor(Color.red);
        g.fillOval(sx/arr.length -5, sy/arr.length -5, 10, 10);
        g.setColor(Color.green);
        g.fillOval(195, 195, 10, 10);
    }

    public boolean centered(Particle[] arr){

            
        int sumx =0;
        int sumy =0;

        for(Particle b: arr){
            sumx += (b.getX()-200);
            sumy+= (b.getY() -200);
        }

        if(sumx/arr.length > -5 && sumx/arr.length < 5 && sumy/arr.length >-5 && sumy/arr.length < 5){
            return true;
        }else{

            return false;   
        }
    }
}
