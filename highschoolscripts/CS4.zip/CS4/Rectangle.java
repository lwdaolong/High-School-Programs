
/**
 * Write a description of class Rectangle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
 class Rectangle extends Polygon
{
    Rectangle(double[] sides){
       super(sides);
    }
    
        public double area(){
        return sides[0]*sides[1];
    }
    
}