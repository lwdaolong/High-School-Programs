
/**
 * Write a description of class Polygon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Polygon
{
    double[] sides;
    
    Polygon(double[] sides){
        this.sides =sides;
        
    }
    
    public double perimeter(){
        double sum =0;
        for(double a: sides){
            sum +=a;
            
        }
        
        return sum;
    }
    
    public double area(){
        return 0;
    }
    
}


