   
/**
 * Write a description of class pset11 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
public class ps11
{

    
     public static void main(String[] args) {
        String[] last = {"Abraham", "Beck", "Crane", "Decker"};
        String[] first = {"Amy", "Bob", "Connor", "Danielle"};
        int[] grad = {2018, 2019, 2019, 2020};
        double[] GPA = {3.3, 3.7, 3.2, 3.8};
        Student[] array = new Student[4];
        for(int i = 0; i < 4; i++) {
            array[i] = new Student(last[i], first[i], grad[i], GPA[i]);
        }
        System.out.println("--- Printing array elements ---");
        for(int i = 0; i < array.length; i++) {
            System.out.println(array[i].data());
        }
        ArrayList <Student> list = new ArrayList();
        for(int i = 0; i < array.length; i++) {
            list.add(array[i]);
        }
        System.out.println("--- Printing List elements ---");
        for(int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).data());
        }
        list.remove(2);
        System.out.println("--- Printing array elements after removing element at index 2 ---");
        for(int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).data());
        }
    }
}
class Student {
    private String first, last;
    private int gradYear;
    private double GPA;
    Student(String first, String last, int gradYear, double GPA) {
        this.first = first;
        this.last = last;
        this.gradYear = gradYear;
        this.GPA = GPA;
    }
    String data() {
        return last + " " + first + " " + gradYear + " " + GPA;
    }
}
