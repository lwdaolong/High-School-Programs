
/**
 * Write a description of class mainpoly here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
public class mainpoly
{
    // instance variables - replace the example below with your own
  
    public static void main(String[] args) {
        int arrnum = (int) Math.random()*10 +30;
        Rectangle [] arr = new Rectangle[arrnum];
        
        for(int i =0; i < arrnum; i++){
            double [] sides1 = new double[2];
                sides1[0] = Math.random()*11 + 1;
                  sides1[1] = Math.random()*11 + 1;
      
            arr[i] = new Rectangle( sides1);
            
        }
        
        
        for(int i=0; i<arrnum; i++){
            System.out.println(arr[i].area());
            
        }
        
        for(int i =0; i< 999; i++){
            
       arr = sort(arr);}
        System.out.println("  *****  ");
                for(int i=0; i<arrnum; i++){
            System.out.println(arr[i].area());
            
        }

    }
    
    public static Rectangle[] sort(Rectangle[] arr){
                for(int i =0; i< arr.length-1; i++){
            if(arr[i].area() > arr[i+1].area()){
                Rectangle temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
            }
            
        }
        return arr;
    }
}
